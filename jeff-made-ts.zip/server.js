import express from "express";
import cors from "cors";
import fetch from "node-fetch";

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const memory = {};

app.post("/ai", async (req,res)=>{

const {message,user} = req.body;

if(!memory[user]) memory[user]=[];

memory[user].push({role:"user",content:message});

const response = await fetch("https://api.openai.com/v1/chat/completions",{
method:"POST",
headers:{
"Content-Type":"application/json",
"Authorization":"Bearer "+process.env.OPENAI_KEY
},
body:JSON.stringify({
model:"gpt-4o-mini",
messages:[
{role:"system",content:"You are Jeff AI. Funny, a little sarcastic but helpful."},
...memory[user]
]
})
});

const data = await response.json();

const reply = data?.choices?.[0]?.message?.content || "AI error";

memory[user].push({role:"assistant",content:reply});

res.json({reply});

});

app.listen(3000,()=>console.log("Server running on port 3000"));