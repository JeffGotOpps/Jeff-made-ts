const user = "user"+Math.floor(Math.random()*100000)

async function send(){

const input=document.getElementById("input")

const msg=input.value

if(!msg) return

const res = await fetch("/ai",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
message:msg,
user:user
})
})

const data = await res.json()

document.getElementById("messages").innerHTML +=
"<p><b>You:</b> "+msg+"</p>"

document.getElementById("messages").innerHTML +=
"<p><b>Jeff:</b> "+data.reply+"</p>"

input.value=""

}